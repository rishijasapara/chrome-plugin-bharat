(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-c0c8d807.js")
    );
  })().catch(console.error);

})();
