console.info("chrome-ext template-vanilla-js background script");
