(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-f61403c2.js")
    );
  })().catch(console.error);

})();
