import"./chunk-2bae8b70.js";document.querySelector("#app").innerHTML=`
  <main>
  <h3>Settings</h3>
  <br>
  <input type="checkbox" id="auto-run-config" name="auto-run-config" checked>Change to Bharat \u{1F1EE}\u{1F1F3} automatically</input>
  <br><br>
  <a href="https://twitter.com/intent/tweet?button_hashtag=BharatDropdownPlugin&ref_src=twsrc%5Etfw" class="twitter-hashtag-button" data-show-count="false">Tweet about #BharatDropdownPlugin</a>
  <br>
  <h6>v1.0</h6>
  <a href="https://x.com/rishijasapara" target="_blank" class="thirteen-bold">Made in Bharat \u2764\uFE0F</a>
  </main>
`;
