console.log("chrome-ext template-vanilla-js content script -1");
