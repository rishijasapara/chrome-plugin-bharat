import"./chunk-2bae8b70.js";document.querySelector("#app").innerHTML=`
<main>
<h3>Bharat \u{1F1EE}\u{1F1F3}</h3>
<p>Automatically convert dropdown option on page load from India \u2192 Bharat</p>
<br>
<p class="thirteen-bold">Note: The option will still remain after Iceland, sorted by "I". Please scroll down or type "BH" when dropdown is focused.</p>
<br>
<a href="https://twitter.com/intent/tweet?button_hashtag=BharatDropdownPlugin&ref_src=twsrc%5Etfw" class="twitter-hashtag-button" data-show-count="false">Tweet about #BharatDropdownPlugin</a>
<br>
<h6>v1.0</h6>
<a href="https://x.com/rishijasapara" target="_blank" class="thirteen-bold">Made in Bharat \u2764\uFE0F</a>
</main>
`;
