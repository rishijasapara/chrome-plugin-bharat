(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-d40bc11d.js")
    );
  })().catch(console.error);

})();
