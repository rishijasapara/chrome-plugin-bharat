console.log("chrome-ext template-vanilla-js background script -1");chrome.runtime.onStartup.addListener(()=>{console.log("onStartup()")});
